#' Check the distribution of individuals based on sum values of SELECTED genes
#' 
#' The data are sum values of selected genes for a group of people.
#' This function generates two plots (histogram and QQ-plot) and a statistical test (Shapiro-Wilk). 
#' We can check if the data is fittig with Gaussian distribution.
#' We treat missing data NA as zero.
#' For input, don't miss quotation marks, and the gene numbers must be less than gene rows in your file.
#' 
#' @param X a vector of a csv file name and some gene numbers you select. 
#' @export 
#' @examples
#' plotsumSelect(c("XYZ.csv", 1, 3, 7))
plotsumSelect <- function(X){
  data = read.csv(X[1], header = T, row.names = 1) 
  n = c()
  for (i in 2:length(X)){
    n[i-1] = as.numeric(X[i])
  }
  L = dim(data)[2] 
  plotvalue = c()
  for (i in 1:L){
    plotvalue[i] = sum(data[, i][n], na.rm = T)
  }
  par(mfrow=c(1,2))
  hist(plotvalue, 
       main="Histogram for Individuals", 
       xlab="Sum value of genes", 
       ylab="Frequency", 
       col="green"
       )
  qqnorm(plotvalue)
  qqline(plotvalue)
  Sum.value.of.selected.genes = plotvalue
  return(list("Null hypothesis is Normal distribution, if p < 0.1 by the following test, then we reject this H0.", shapiro.test(Sum.value.of.selected.genes)))
}
