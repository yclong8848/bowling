#' Check the distribution of individuals based on sum values of ALL genes
#' 
#' The data are sum values of all genes for a group of people.
#' This function generates two plots (histogram and QQ-plot) and a statistical test (Shapiro-Wilk). 
#' We can check if the data is fittig with Gaussian distribution.
#' We treat missing data NA as zero.
#' For input, don't miss quotation marks, and the gene numbers must be less than gene rows in your file.
#' 
#' @param X a vector of a csv file. 
#' @export 
#' @examples
#' plotsumAll("XYZ.csv")
plotsumAll <- function(X){
  data = read.csv(X, header = T, row.names = 1) 
  L = dim(data)[2] 
  plotvalue = c()
  for (i in 1:L){
    plotvalue[i] = sum(data[, i], na.rm = T)
  }
  par(mfrow=c(1,2))
  hist(plotvalue, 
       main="Histogram for Individuals", 
       xlab="Sum value of genes", 
       ylab="Frequency", 
       col="green"
       )
  qqnorm(plotvalue)
  qqline(plotvalue)
  Sum.value.of.all.genes = plotvalue
  return(list("Null hypothesis is Normal distribution, if p < 0.1 by the following test, then we reject this H0.", shapiro.test(Sum.value.of.all.genes)))
}
